import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Product, MemeItem, Order } from '../types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isClientSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase: SupabaseClient | null = isClientSupabaseConfigured
  ? createClient(supabaseUrl!, supabaseAnonKey!)
  : null;

export interface SupabaseStatus {
  configured: boolean;
  connected: boolean;
  mode: 'supabase-live' | 'local-fallback';
  url: string | null;
  tables?: {
    products: boolean;
    orders: boolean;
    memes: boolean;
  };
  error?: string;
}

export async function getBackendSupabaseStatus(): Promise<SupabaseStatus> {
  try {
    const res = await fetch('/api/supabase/status');
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const data = await res.json();
    return {
      configured: data.configured,
      connected: data.connected,
      mode: data.connected ? 'supabase-live' : 'local-fallback',
      url: data.url,
      tables: data.tables,
      error: data.error,
    };
  } catch (err: any) {
    if (isClientSupabaseConfigured && supabase) {
      try {
        const { error } = await supabase.from('products').select('id').limit(1);
        return {
          configured: true,
          connected: !error,
          mode: !error ? 'supabase-live' : 'local-fallback',
          url: supabaseUrl || null,
          error: error?.message,
        };
      } catch (e: any) {
        return {
          configured: true,
          connected: false,
          mode: 'local-fallback',
          url: supabaseUrl || null,
          error: e.message,
        };
      }
    }

    return {
      configured: false,
      connected: false,
      mode: 'local-fallback',
      url: null,
      error: 'Backend API or Supabase credentials not detected',
    };
  }
}

// Map Supabase DB row to Product model
export function rowToProduct(row: any): Product {
  return {
    id: row.id,
    name: row.name,
    tagline: row.tagline || '',
    description: row.description || '',
    price: Number(row.price),
    originalPrice: row.original_price ? Number(row.original_price) : undefined,
    image: row.image,
    category: row.category,
    dietary: Array.isArray(row.dietary) ? row.dietary : [],
    memeBadge: row.meme_badge || undefined,
    badgeColor: row.badge_color || undefined,
    inStock: Boolean(row.in_stock),
    stockCount: Number(row.stock_count ?? 20),
    weightGrams: row.weight_grams ? Number(row.weight_grams) : undefined,
    isCustomizable: Boolean(row.is_customizable),
    customPlaceholder: row.custom_placeholder || undefined,
    rating: Number(row.rating || 4.9),
    reviewCount: Number(row.review_count || 12),
    ingredientsSnippet: row.ingredients_snippet || undefined,
  };
}

// Fetch products: tries Supabase client first, falls back to Express /api/products
export async function fetchProductsData(): Promise<Product[]> {
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');
      if (!error && data && data.length > 0) {
        return data.map(rowToProduct);
      }
    } catch (e) {
      console.warn('Supabase client product query failed, using API/fallback:', e);
    }
  }

  // Fallback to Express backend or static data
  try {
    const res = await fetch('/api/products');
    if (res.ok) {
      const json = await res.json();
      if (json.products && Array.isArray(json.products)) {
        return json.products;
      }
    }
  } catch (err) {
    console.warn('API /api/products not available:', err);
  }

  return [];
}

// Fetch memes: tries Supabase client first, falls back to Express /api/memes
export async function fetchMemesData(): Promise<MemeItem[]> {
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('memes')
        .select('*')
        .order('likes', { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map(row => ({
          id: row.id,
          title: row.title,
          caption: row.caption,
          image: row.image,
          likes: row.likes || 0,
          author: row.author,
          tag: row.tag,
          vibeCookieRecommendation: row.vibe_cookie_recommendation,
        }));
      }
    } catch (e) {
      console.warn('Supabase client memes query failed, using API/fallback:', e);
    }
  }

  try {
    const res = await fetch('/api/memes');
    if (res.ok) {
      const json = await res.json();
      if (json.memes && Array.isArray(json.memes)) {
        return json.memes;
      }
    }
  } catch (err) {
    console.warn('API /api/memes not available:', err);
  }

  return [];
}

// Like meme: tries Supabase or API
export async function likeMemeAction(id: string): Promise<MemeItem | null> {
  if (supabase) {
    try {
      // Fetch current likes
      const { data: current } = await supabase
        .from('memes')
        .select('likes')
        .eq('id', id)
        .single();
      const nextLikes = (current?.likes || 0) + 1;
      const { data, error } = await supabase
        .from('memes')
        .update({ likes: nextLikes })
        .eq('id', id)
        .select()
        .single();

      if (!error && data) {
        return {
          id: data.id,
          title: data.title,
          caption: data.caption,
          image: data.image,
          likes: data.likes || 0,
          author: data.author,
          tag: data.tag,
          vibeCookieRecommendation: data.vibe_cookie_recommendation,
        };
      }
    } catch (e) {
      console.warn('Supabase like error, attempting API route:', e);
    }
  }

  try {
    const res = await fetch(`/api/memes/${id}/like`, { method: 'POST' });
    if (res.ok) {
      const json = await res.json();
      return json.meme;
    }
  } catch (err) {
    console.error('Failed to like meme via API:', err);
  }
  return null;
}

// Add meme: tries Supabase or API
export async function addMemeAction(newMeme: Omit<MemeItem, 'id' | 'likes'>): Promise<MemeItem | null> {
  const memeId = `meme-${Date.now()}`;
  if (supabase) {
    try {
      const row = {
        id: memeId,
        title: newMeme.title,
        caption: newMeme.caption,
        image: newMeme.image,
        likes: 0,
        author: newMeme.author || 'Plug Bestie',
        tag: newMeme.tag || '#pevibes',
        vibe_cookie_recommendation: newMeme.vibeCookieRecommendation || null,
        created_at: new Date().toISOString(),
      };
      const { data, error } = await supabase.from('memes').insert([row]).select().single();
      if (!error && data) {
        return {
          id: data.id,
          title: data.title,
          caption: data.caption,
          image: data.image,
          likes: data.likes || 0,
          author: data.author,
          tag: data.tag,
          vibeCookieRecommendation: data.vibe_cookie_recommendation,
        };
      }
    } catch (e) {
      console.warn('Supabase add meme failed, trying API route:', e);
    }
  }

  try {
    const res = await fetch('/api/memes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newMeme),
    });
    if (res.ok) {
      const json = await res.json();
      return json.meme;
    }
  } catch (err) {
    console.error('Failed to add meme via API:', err);
  }
  return null;
}
